package Reservation;

public class mtTblVO {
	private int mtNum;
	private String mtDate;
	private String mtMovie;
	private String mtTimeline;
	private int mtPeople;
	private int mtTotalPeople;
	
	public int getMtNum() {
		return mtNum;
	}
	public void setMtNum(int mtNum) {
		this.mtNum = mtNum;
	}
	public String getMtDate() {
		return mtDate;
	}
	public void setMtDate(String mtDate) {
		this.mtDate = mtDate;
	}
	public String getMtMovie() {
		return mtMovie;
	}
	public void setMtMovie(String mtMovie) {
		this.mtMovie = mtMovie;
	}
	public String getMtTimeline() {
		return mtTimeline;
	}
	public void setMtTimeline(String mtTimeline) {
		this.mtTimeline = mtTimeline;
	}
	public int getMtPeople() {
		return mtPeople;
	}
	public void setMtPeople(int mtPeople) {
		this.mtPeople = mtPeople;
	}
	public int getMtTotalPeople() {
		return mtTotalPeople;
	}
	public void setMtTotalPeople(int mtTotalPeople) {
		this.mtTotalPeople = mtTotalPeople;
	}
}
