package AdminDAODTO;

public class MovieImgVO {
	private int movieRank;
	private String movieName;
	private float movieSalesShare;
	private String movieCd;
	private int salesAmt;
	private int audiCnt;
	private int audiAcc;
	private int rankInten;
	private String rankOldAndNew;
	
	public int getMovieRank() {
		return movieRank;
	}
	public void setMovieRank(int movieRank) {
		this.movieRank = movieRank;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public float getmovieSalesShare() {
		return movieSalesShare;
	}
	public void setmovieSalesShare(float movieSalesShare) {
		this.movieSalesShare = movieSalesShare;
	}
	public String getMovieCd() {
		return movieCd;
	}
	public void setMovieCd(String movieCd) {
		this.movieCd = movieCd;
	}
	public int getSalesAmt() {
		return salesAmt;
	}
	public void setSalesAmt(int salesAmt) {
		this.salesAmt = salesAmt;
	}
	public int getAudiCnt() {
		return audiCnt;
	}
	public void setAudiCnt(int audiCnt) {
		this.audiCnt = audiCnt;
	}
	public int getAudiAcc() {
		return audiAcc;
	}
	public void setAudiAcc(int audiAcc) {
		this.audiAcc = audiAcc;
	}
	public int getRankInten() {
		return rankInten;
	}
	public void setRankInten(int rankInten) {
		this.rankInten = rankInten;
	}
	public String getRankOldAndNew() {
		return rankOldAndNew;
	}
	public void setRankOldAndNew(String rankOldAndNew) {
		this.rankOldAndNew = rankOldAndNew;
	}
	
}
