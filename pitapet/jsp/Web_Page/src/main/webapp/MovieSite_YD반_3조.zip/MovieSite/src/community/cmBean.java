package community;

public class cmBean {
	private int cmRank;
	private String cmTitle;
	private String cmID;
	private String cmDate;
	private String cmContent;
	private int cmAvailable;
	
	public int getCmRank() {
		return cmRank;
	}
	public void setCmRank(int cmRank) {
		this.cmRank = cmRank;
	}
	public String getCmTitle() {
		return cmTitle;
	}
	public void setCmTitle(String cmTitle) {
		this.cmTitle = cmTitle;
	}
	public String getCmID() {
		return cmID;
	}
	public void setCmID(String cmID) {
		this.cmID = cmID;
	}
	public String getCmDate() {
		return cmDate;
	}
	public void setCmDate(String cmDate) {
		this.cmDate = cmDate;
	}
	public String getCmContent() {
		return cmContent;
	}
	public void setCmContent(String cmContent) {
		this.cmContent = cmContent;
	}
	public int getCmAvailable() {
		return cmAvailable;
	}
	public void setCmAvailable(int cmAvailable) {
		this.cmAvailable = cmAvailable;
	}
}