package community;

public class cmAdBean {
	private int adminRank;
	private String adminTitle;
	private String adminID;
	private String adminDate;
	private String adminContent;
	private int adminAvailable;
	
	public int getAdminRank() {
		return adminRank;
	}
	public void setAdminRank(int adminRank) {
		this.adminRank = adminRank;
	}
	public String getAdminTitle() {
		return adminTitle;
	}
	public void setAdminTitle(String adminTitle) {
		this.adminTitle = adminTitle;
	}
	public String getAdminID() {
		return adminID;
	}
	public void setAdminID(String adminID) {
		this.adminID = adminID;
	}
	public String getAdminDate() {
		return adminDate;
	}
	public void setAdminDate(String adminDate) {
		this.adminDate = adminDate;
	}
	public String getAdminContent() {
		return adminContent;
	}
	public void setAdminContent(String adminContent) {
		this.adminContent = adminContent;
	}
	public int getAdminAvailable() {
		return adminAvailable;
	}
	public void setAdminAvailable(int adminAvailable) {
		this.adminAvailable = adminAvailable;
	}
}
