package AdminDAODTO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import memberRegister.RegisterBean;


public class AdminDAO {
	static Connection conn = null;
	static PreparedStatement pstmt = null;

	/* Mysql 연결 */
	
	// Mysql Driver
	static String DRIVER = "com.mysql.cj.jdbc.Driver";
	// Mysql DB 연결 주소
    static String DB = "jdbc:mysql://localhost:3306/moviesite?useUnicode=true&characterEncoding=utf-8";
    // Mysql 계정 ID
	static String USER = "root";
	// Mysql 계정 PWD
	static String PW = "root";
	
	// DB연결 메서드
	static void connect() {
		try {
			Class.forName(DRIVER);
			conn = DriverManager.getConnection(DB,USER,PW);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// DB 연결 끊기 메서드
	static void disconnect() {
		if(pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} 
		if(conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	// 회원 목록 가져오기
	public ArrayList<RegisterBean> selectUserDB() {
		// 위에 만들어놓은 connect()로 DB와 연결하기
		connect();
		// SQL 구문을 변수에 미리 집어 넣기 
		String SQL = "SELECT * FROM membermovie";
		
		// ArrayList<RegisterBean>의 형태로 반환하기 위해서 list 객체 만들어주기
		ArrayList<RegisterBean> list = new ArrayList<RegisterBean>();
		try {
			// SQL 명령어를 준비시켜놓기
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			// SQL 명령어 실행(SELECT * FROM membermovie)
			ResultSet rs = pstmt.executeQuery();
			
			// 가져온 데이터를 하나씩 순차적으로 검색
			while(rs.next()) {
				// 사용자 객체를 만듦
				RegisterBean member = new RegisterBean();
				// 그 객체의 id를 rs(조회한 데이터)의 컬럼명 memberid를 불러와서 설정 
				member.setMemberid(rs.getString("memberid"));
				member.setPassword(rs.getString("password"));
				member.setName(rs.getString("name"));
				member.setEmail(rs.getString("email"));
				member.setTel(rs.getString("tel"));
				member.setMemberRank(rs.getString("memberRank"));
				// 멤버 리스트에 멤버 담기
				list.add(member);		
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			disconnect();
		}
		
		return list; 
	}
	
	public static String selectUserName(String userid) {
		String UserName = null;
		connect();
		String sql = "select name from membermovie where memberid=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				UserName = rs.getString("name");
			} else {
				UserName = "selectUserName() Error";
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return UserName;
	}
	
	public static String selectUserRank(String userid) {
		String UserRank = null;
		connect();
		String sql = "select memberRank from membermovie where memberid=?";
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, userid);
				ResultSet rs = pstmt.executeQuery();
				if(rs.next()) {
					UserRank = rs.getString("memberRank");
				} else {
					UserRank = "selectUserRank() Error";
				}
			} catch(Exception e) {
				e.printStackTrace();
			} finally {
				disconnect();
			}
			return UserRank;
	}
	
	public static String[] selectUserInfo(String userid) {
		connect();
		String sql = "select * from membermovie where memberid=?";
		String[] user_list = new String[6];
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				user_list[0] = rs.getString("memberid");
				user_list[1] = rs.getString("password");
				user_list[2] = rs.getString("name");
				user_list[3] = rs.getString("email");
				user_list[4] = rs.getString("tel");
				user_list[5] = rs.getString("memberRank");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return user_list;
	}
	
	public static int DeleteDB(String userid) {
		connect();
		int result = 0;
		String sql = "DELETE from membermovie where memberid=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return result;
	}
	
	public static int UpdateDB(String id, String updateId, String updatePw, String updateName, String updateEmail, String updateTel, String updateRank) {
		connect();
		int result = 0;
		String sql = "UPDATE membermovie SET memberid=?, password=?, name=?, email=?, tel=?, memberRank=? where memberid=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, updateId);
			pstmt.setString(2, updatePw);
			pstmt.setString(3, updateName);
			pstmt.setString(4, updateEmail);
			pstmt.setString(5, updateTel);
			pstmt.setString(6, updateRank);
			pstmt.setString(7, id);
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return result;
	}
	
	/* 회원 목록 가져오기
		public RegisterBean selectUser(String userid) {
			// 위에 만들어놓은 connect()로 DB와 연결하기
			connect();
			// SQL 구문을 변수에 미리 집어 넣기 
			String SQL = "SELECT * FROM membermovie";
			
			// ArrayList<RegisterBean>의 형태로 반환하기 위해서 list 객체 만들어주기
			ArrayList<RegisterBean> list = new ArrayList<RegisterBean>();
			try {
				// SQL 명령어를 준비시켜놓기
				PreparedStatement pstmt = conn.prepareStatement(SQL);
				// SQL 명령어 실행(SELECT * FROM membermovie)
				ResultSet rs = pstmt.executeQuery();
				
				// 가져온 데이터를 하나씩 순차적으로 검색
				while(rs.next()) {
					// 사용자 객체를 만듦
					RegisterBean member = new RegisterBean();
					// 그 객체의 id를 rs(조회한 데이터)의 컬럼명 memberid를 불러와서 설정 
					member.setMemberid(rs.getString("memberid"));
					member.setPassword(rs.getString("password"));
					member.setName(rs.getString("name"));
					member.setEmail(rs.getString("email"));
					member.setTel(rs.getString("tel"));
					// 멤버 리스트에 멤버 담기
					list.add(member);		
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			finally {
				disconnect();
			}
			
			return list; 
		}
*/
}
