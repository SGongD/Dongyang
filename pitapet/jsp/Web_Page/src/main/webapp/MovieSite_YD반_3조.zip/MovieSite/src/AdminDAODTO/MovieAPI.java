package AdminDAODTO;

import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.IOException;


public class MovieAPI {
	private ArrayList<HashMap<String, String>> movieList = new ArrayList<HashMap<String, String>>();
	public String result;

	
	// 일별 박스오피스 요청 함수
    public String RequestDayBoxOffice() throws IOException {
    	
    	String movieURL = "http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json"; /* 요청 주소  */
    	String apiKey = "0d42cc2f1932dba3c9df7334b4a14e48"; /* 영화진흥위원회에서 받은 인증키 */
    	String targetDate = "20211206"; /* 요청 날짜 */
 
    	
    	// StringBuilder는 String에 String을 더할 때 연산을 조금 더 빠르게 해줄 수 있는 객체임
        StringBuilder urlBuilder = new StringBuilder(movieURL); /* 요청 주소 */
        
        // 기존 주소에 append 함수로 파라미터 추가
        urlBuilder.append("?" + URLEncoder.encode("key","UTF-8") + "=" + URLEncoder.encode(apiKey, "UTF-8")); /* 인증 키 */
        urlBuilder.append("&" + URLEncoder.encode("targetDt","UTF-8") + "=" + URLEncoder.encode(targetDate, "UTF-8")); /* 공공데이터포털에서 받은 인증키 */
        
        // 기존 주소에 모든 파라미터를 합쳤으면 주소 형태의 객체로 바꿔준다.
        URL url = new URL(urlBuilder.toString());
        
        // URL 주소로 연결을 활성화 시킨다
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        
        // 방식은 GET 방식
        conn.setRequestMethod("GET");
        
        BufferedReader rd;
        // 만약 서버가 정상적으로 데이터를 받았으면 rd라는 버퍼에 응답한 결과 값을 담는다
        if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } 
        // 실패했으면 rd라는 버퍼에 응답한 에러 결과 값을 담는다.
        else {
            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        }
        StringBuilder sb = new StringBuilder();
        String line;
        // 버퍼에 담은 값을 String 형태로 만들어준다.
        while ((line = rd.readLine()) != null) {
            sb.append(line);
        }
        
        // 버퍼 종료 
        rd.close();
        // URL 연결 종료
        conn.disconnect();
   
        // 응답 받은 결과 값을 result 변수에 저장
        result = sb.toString();

		return result;
    }
    
    // DB에 위에서 구한 일별 박스오피스를 저장
    public void MovieList(String API) {	
        JSONParser parser = new JSONParser();
        try {
        	// 파서로 응답 받은 결과 body를 쪼개기
    		JSONObject obj = (JSONObject)parser.parse(API);
    		// 가장 최상위인 boxOfficeResult 가져오기
    		JSONObject obj2 = (JSONObject)obj.get("boxOfficeResult");
    		// 그 하위 항목중 dailyBoxOfficeList를 가져오는데 배열이기때문에 JSONArray로 가져옴
    		JSONArray dailybox = (JSONArray)obj2.get("dailyBoxOfficeList");
    		MovieImgDAO.deleteDB();
    		// 배열을 돌면서
    		for(int i=0;i<dailybox.size();i++){
    			JSONObject tmp = (JSONObject)dailybox.get(i); //인덱스 번호로 접근해서 첫번째 부터 가져오기

    			int movieRank = Integer.valueOf((String) tmp.get("rank"));
    			String movieName = (String)tmp.get("movieNm");
    			float movieSalesShare = Float.valueOf((String) tmp.get("salesShare"));
    			String movieCd = (String)tmp.get("movieCd");
    			int salesAmt = Integer.valueOf((String) tmp.get("salesAmt"));
    			int audiCnt = Integer.valueOf((String) tmp.get("audiCnt"));
    			int audiAcc = Integer.valueOf((String) tmp.get("audiAcc"));
    			int rankInten = Integer.valueOf((String) tmp.get("rankInten"));
    			String rankOldAndNew = (String)tmp.get("rankOldAndNew");

    			MovieImgDAO.insertDB(movieRank, movieName, movieSalesShare, movieCd, salesAmt, audiCnt, audiAcc, rankInten, rankOldAndNew);			
    		}
    	} catch (ParseException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
    }
}