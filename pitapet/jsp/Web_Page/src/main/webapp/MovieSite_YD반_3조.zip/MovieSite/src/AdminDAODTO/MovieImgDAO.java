package AdminDAODTO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MovieImgDAO {
	static Connection conn = null;
	static PreparedStatement pstmt = null;
	static ResultSet rs = null;

	/* Mysql 연결 */
	
	// Mysql Driver
	static String DRIVER = "com.mysql.cj.jdbc.Driver";
	// Mysql DB 연결 주소
    static String DB = "jdbc:mysql://localhost:3306/moviesite?useUnicode=true&characterEncoding=utf-8" ;
    // Mysql 계정 ID
	static String USER = "root";
	// Mysql 계정 PWD
	static String PW = "root";
	
	// DB연결 메서드
	static void connect() {
		try {
			Class.forName(DRIVER);
			conn = DriverManager.getConnection(DB,USER,PW);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// DB 연결 끊기 메서드
	static void disconnect() {
		if(pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} 
		if(conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	// 영화 순위, 영화 제목, 영화 코드를 DB에 삽입
	public static void insertDB(int mv1, String mv2, float mv3, String mv4, int mv5, int mv6, int mv7, int mv8, String mv9) {
		// DB 연결
		connect();
		
		// SQL 구문
		String sql = "insert into movie values(?,?,?,?,?,?,?,?,?)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, mv1);
			pstmt.setString(2, mv2);
			pstmt.setFloat(3, mv3);
			pstmt.setString(4, mv4);
			pstmt.setInt(5, mv5);
			pstmt.setInt(6, mv6);
			pstmt.setInt(7, mv7);
			pstmt.setInt(8, mv8);
			pstmt.setString(9, mv9);
			
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
	}
	
	public static void deleteDB() {
		connect();
		String sql = "TRUNCATE movie";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
	}
	
	// 입력 받은 값만큼 영화 순위 순서대로 출력
	public static ArrayList<MovieImgVO> selectMovieRank(int num) {
		int count = 0;
		connect();
		String sql = "SELECT * FROM movie order by movieRank asc;";
		ArrayList<MovieImgVO> list = new ArrayList<MovieImgVO>();
		try {
			 pstmt = conn.prepareStatement(sql);
			 rs = pstmt.executeQuery();
			 while(rs.next()) {
				 if(count < num) {
					 MovieImgVO movie = new MovieImgVO();
					 movie.setMovieRank(rs.getInt("movieRank"));
					 movie.setMovieName(rs.getString("movieName"));
					 movie.setmovieSalesShare(rs.getFloat("movieSalesShare"));
					 movie.setMovieCd(rs.getString("movieCd"));
					 list.add(movie);
					 count += 1;
				 }
			 }
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return list;
	}
	
	public static ArrayList<MovieImgVO> DailyBoxOffice() {
		connect();
		String sql = "SELECT * FROM movie order by movieRank asc";
		ArrayList<MovieImgVO> daybox = new ArrayList<MovieImgVO>();
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				MovieImgVO DBO = new MovieImgVO();
				DBO.setMovieRank(rs.getInt("movieRank"));
				DBO.setMovieName(rs.getString("movieName"));
				DBO.setSalesAmt(rs.getInt("salesAmt"));
				DBO.setAudiCnt(rs.getInt("audiCnt"));
				DBO.setAudiAcc(rs.getInt("audiAcc"));
				DBO.setRankInten(rs.getInt("rankInten"));
				DBO.setRankOldAndNew(rs.getString("rankOldAndNew"));
				daybox.add(DBO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return daybox;
	}
	
	public static String selectRankOldAndNew(int rankInten, String rankOldAndNew) {
		String RankStr;
		if(rankOldAndNew.equals("NEW")) {
			RankStr = "NEW";
			return RankStr;
		}
		else {
			if(rankInten == 0) {
				RankStr = "-";
				return RankStr;
			} else if(rankInten > 0){
				RankStr = "↑ " + rankInten;
				return RankStr;
			} else {
				RankStr = "↓ " + Math.abs(rankInten);
				return RankStr;
			}
		}
	}
}
