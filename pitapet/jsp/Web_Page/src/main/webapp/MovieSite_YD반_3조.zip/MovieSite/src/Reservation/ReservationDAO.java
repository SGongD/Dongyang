package Reservation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import community.cmAdBean;
import community.cmBean;
import memberRegister.RegisterBean;

public class ReservationDAO {
	static Connection conn = null;
	static PreparedStatement pstmt = null;
	static ResultSet rs = null;

	/* Mysql 연결 */
	
	// Mysql Driver
	static String DRIVER = "com.mysql.cj.jdbc.Driver";
	// Mysql DB 연결 주소
    static String DB = "jdbc:mysql://localhost:3306/moviesite?useUnicode=true&characterEncoding=utf-8";
    // Mysql 계정 ID
	static String USER = "root";
	// Mysql 계정 PWD
	static String PW = "root";
	
	// DB연결 메서드
	static void connect() {
		try {
			Class.forName(DRIVER);
			conn = DriverManager.getConnection(DB,USER,PW);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// DB 연결 끊기 메서드
	static void disconnect() {
		if(pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public String getDate() {
		Date now = new Date();
		//현재 날짜/시간 출력
		System.out.println(now); // Thu Jun 17 06:57:32 KST 2021
		//포맷팅 정의
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		
		// 포맷팅 적용
		String formatedNow = formatter.format(now);

		return formatedNow;
	}
	
	public int getNext() {
		String SQL = "SELECT mtNum FROM mtTBL ORDER BY mtNum DESC";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1; //첫 번째 게시물인 경우
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; //데이터베이스 오류
	}
	
	public int getNext2() {
		String SQL = "SELECT ticketNum FROM mtTBL ORDER BY ticketNum DESC";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1; //첫 번째 게시물인 경우
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; //데이터베이스 오류
	}
	
	public void deleteDB() {
		connect();
		String sql = "TRUNCATE mtTBL";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
	}
	
	public void deleteTtDB() {
		connect();
		String sql = "TRUNCATE ticketTBL";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
	}
	
	public int[] select_mtPeople() {
		int[] mtPeople_list = new int[360];
		int zero_count = 0;
		int count = 0;
		connect();
		String sql = "select mtPeople from mtTBL";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				mtPeople_list[count] = rs.getInt("mtPeople");
				if(rs.getInt("mtPeople")==0) {
					zero_count = zero_count + 1;
				}
				count = count + 1;
			}
			if(zero_count == 360) {
				for(int i=0; i<360; i++) {
					mtPeople_list[i] = 40;
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			for(int i=0; i<360; i++) {
				mtPeople_list[i] = 40;
			}
		} finally {
			disconnect();
		}
		return mtPeople_list;
	}
	
	public int mtInsert(String movieName, int[] mtPeople) {
		int count = 0;
		int zero_count = 0;
		connect();
		String time[] = {"10:40", "13:00", "15:30", "19:20"};
		String place[] = {"CGV 압구정", "메가박스 코엑스", "CGV 강남", "롯데시네마-브로드웨이(신사)",
				"메가박스 씨티(강남대로)", "이봄씨어터", "롯데시네마-도곡", "롯데시네마-강동", "CGV 송파"};
		String sql = "INSERT INTO mtTBL VALUES(?, ?, ?, ?, ?, ?, ?)";
		for(int i=0; i<360; i++) {
			if(mtPeople[i]==0) {
				zero_count++;
			}
		}
		if(zero_count == 360) {
			for(int i=0; i<360; i++) {
				mtPeople[i] = 40;
			}
		}
		try {
			String date = getDate().substring(0, 10);
			for(int i=0; i<9; i++) {
				for(int k=0; k<4; k++) {
					pstmt = conn.prepareStatement(sql);
					pstmt.setInt(1, getNext());
					pstmt.setString(2, date);
					pstmt.setString(3, movieName);
					pstmt.setString(4, place[i]);
					pstmt.setString(5, time[k]);
					pstmt.setInt(6, mtPeople[count]);
					pstmt.setInt(7, 40);
					pstmt.executeUpdate();
					count = count + 1;
				}
				count = count + 1;
			}
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return -1;
	}
	
	public int mtUpdate(String movieName, String Cinema, String Timeline, int People) {
		int mtNum = 0;
		int mtPeople = 0;
		connect();
		String select_mtNum_sql = "select mtNum, mtPeople from mtTBL where mtMovie = ? AND mtCinema = ? AND mtTimeline = ?";
		String sql = "UPDATE mtTBL SET mtPeople=? where mtNum=?";
		try {
			PreparedStatement select_mtNum_pstmt = conn.prepareStatement(select_mtNum_sql);
			select_mtNum_pstmt.setString(1, movieName);
			select_mtNum_pstmt.setString(2, Cinema);
			select_mtNum_pstmt.setString(3, Timeline);
			ResultSet select_mtNum_rs = select_mtNum_pstmt.executeQuery();
			if(select_mtNum_rs.next()) {
				mtNum = select_mtNum_rs.getInt("mtNum");
				mtPeople = select_mtNum_rs.getInt("mtPeople");
			}
			select_mtNum_rs.close();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, mtPeople-People);
			pstmt.setInt(2, mtNum);
			pstmt.executeUpdate();
			
			
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return -1;
	}
	
	public int ticketInsert(String movieName, String Cinema, String Timeline, String Date, String Reservator, String People) {
		connect();
		String sql = "INSERT INTO ticketTBL(ticketMovie, ticketCinema, ticketTimeline, ticketDate, ticketReservator, ticketPeople) VALUES(?, ?, ?, ?, ?, ?)";
		try {
			int tPeople = Integer.valueOf((String) People);
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, movieName);
			pstmt.setString(2, Cinema);
			pstmt.setString(3, Timeline);
			pstmt.setString(4, Date);
			pstmt.setString(5, Reservator);
			pstmt.setInt(6, tPeople);
			pstmt.executeUpdate();
			
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return -1;
	}
	
	public ArrayList<ticketTblVO> ticketList() {
		// 위에 만들어놓은 connect()로 DB와 연결하기
		connect();
		// SQL 구문을 변수에 미리 집어 넣기 
		String SQL = "SELECT * FROM tickettbl";
		
		// ArrayList<cmDAO>의 형태로 반환하기 위해서 list 객체 만들어주기
		ArrayList<ticketTblVO> list = new ArrayList<ticketTblVO>();
		try {
			// SQL 명령어를 준비시켜놓기
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			ResultSet rs = pstmt.executeQuery();
			
			// 가져온 데이터를 하나씩 순차적으로 검색
			while(rs.next()) {
				// 사용자 객체를 만듦
				ticketTblVO tT = new ticketTblVO();

				tT.setTicketNum(rs.getInt("ticketNum"));
				tT.setTicketMovie(rs.getString("ticketMovie"));
				tT.setTicketCinema(rs.getString("ticketCinema"));
				tT.setTicketTimeline(rs.getString("ticketTimeline"));
				tT.setTicketDate(rs.getString("ticketDate"));
				tT.setTicketReservator(rs.getString("ticketReservator"));
				tT.setTicketPeoPle(rs.getInt("ticketPeople"));
				// 멤버 리스트에 멤버 담기
				list.add(tT);		
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			disconnect();
		}
		
		return list; 
	}
	
	// 잔여수
	public ArrayList<mtTblVO> getTimelineList(String moviename, String cinema) {
		connect();
		String sql = "select * from mtTBL where mtMovie=? and mtCinema=?";
		ArrayList<mtTblVO> voList = new ArrayList<mtTblVO>();
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, moviename);
			pstmt.setString(2, cinema);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				mtTblVO vo = new mtTblVO();
				vo.setMtTimeline(rs.getString("mtTimeline"));
				vo.setMtTotalPeople(rs.getInt("mtTotalPeople"));
				vo.setMtPeople(rs.getInt("mtPeople"));

				voList.add(vo);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {
			disconnect();
		}
		return voList;
	}
}
