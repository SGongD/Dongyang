package community;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import community.cmAdBean;
import memberRegister.RegisterBean;

public class cmDAO {
	static Connection conn = null;
	static PreparedStatement pstmt = null;

	/* Mysql 연결 */
	
	// Mysql Driver
	static String DRIVER = "com.mysql.cj.jdbc.Driver";
	// Mysql DB 연결 주소
    static String DB = "jdbc:mysql://localhost:3306/moviesite?useUnicode=true&characterEncoding=utf-8";
    // Mysql 계정 ID
	static String USER = "root";
	// Mysql 계정 PWD
	static String PW = "root";
	
	// DB연결 메서드
	static void connect() {
		try {
			Class.forName(DRIVER);
			conn = DriverManager.getConnection(DB,USER,PW);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// DB 연결 끊기 메서드
		static void disconnect() {
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} 
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	
	public String getDate() {
		String SQL = "SELECT NOW()";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ""; //데이터베이스 오류
	}
	
	public int getNext() {
		String SQL = "SELECT cmRank FROM COMMUNITY ORDER BY cmRank DESC";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1; //첫 번째 게시물인 경우
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; //데이터베이스 오류
	}
	
	public int getNext2() {
		String SQL = "SELECT adminRank FROM adminwrite ORDER BY adminRank DESC";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1; //첫 번째 게시물인 경우
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; //데이터베이스 오류
	}
	
	//커뮤니티 글쓰기
	public int write(String cmTitle, String cmID, String cmContent) {
		connect();
		String SQL = "INSERT INTO COMMUNITY VALUE(?, ?, ?, ?, ?, ?)"; 
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext()); //인덱스
			pstmt.setString(2, cmTitle); //글 제목
			pstmt.setString(3, cmID); // 작성자 아이디
			pstmt.setString(4, getDate()); // 글 작성 시간
			pstmt.setString(5, cmContent); // 글 내용
			pstmt.setInt(6, 1); // 글 작성 가능 여부
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return -1; //데이터베이스 오류
	}
	
	//커뮤니티 글 삭제
	public static int cmDelete(String cmRank) {
		connect();
		int result = 1;
		String sql = "DELETE from community where cmRank=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cmRank);
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return result;
	}
	
	//커뮤티니 글 수정
	public static int cmUpdate(String cmRank, String cmTitle, String cmID, String cmDate, String cmContent, String cmAvailable) {
		connect();
		int result = 0;
		String sql = "UPDATE adminwrite SET cmRank=?, cmTitle=?, cmID=?, cmDate=?, cmContent=?, cmAvailable=?";
		try {
			int cRank = Integer.valueOf((String) cmRank);
			int cAvailable = Integer.valueOf((String) cmAvailable);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, cRank);
			pstmt.setString(2, cmTitle);
			pstmt.setString(3, cmID);
			pstmt.setString(4, cmDate);
			pstmt.setString(5, cmContent);
			pstmt.setInt(6, cAvailable);
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return result;
	}
	
	// 글 목록 가져오기
	public ArrayList<cmBean> cmWriteList() {
		// 위에 만들어놓은 connect()로 DB와 연결하기
		connect();
		// SQL 구문을 변수에 미리 집어 넣기 
		String SQL = "SELECT * FROM community";
		
		// ArrayList<cmDAO>의 형태로 반환하기 위해서 list 객체 만들어주기
		ArrayList<cmBean> list = new ArrayList<cmBean>();
		try {
			// SQL 명령어를 준비시켜놓기
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			// SQL 명령어 실행(SELECT * FROM community)
			ResultSet rs = pstmt.executeQuery();
			
			// 가져온 데이터를 하나씩 순차적으로 검색
			while(rs.next()) {
				// 사용자 객체를 만듦
				cmBean cmB = new cmBean();
				// 그 객체의 id를 rs(조회한 데이터)의 컬럼명 cmRank를 불러와서 설정 
				cmB.setCmRank(rs.getInt("cmRank"));
				cmB.setCmTitle(rs.getString("cmTitle"));
				cmB.setCmID(rs.getString("cmID"));
				cmB.setCmDate(rs.getString("cmDate"));
				cmB.setCmContent(rs.getString("cmContent"));
				cmB.setCmAvailable(rs.getInt("cmAvailable"));
				// 멤버 리스트에 멤버 담기
				list.add(cmB);		
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			disconnect();
		}
		
		return list; 
	}
			
	// 커뮤니티 글 출력
	public static String[] cmWriteEdit(int cmRank) {
		connect();
		String sql = "select * from community where cmRank=?";
		String[] cm_post = new String[6];
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, cmRank);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				cm_post[0] = rs.getString("cmRank");
				cm_post[1] = rs.getString("cmTitle");
				cm_post[2] = rs.getString("cmID");
				cm_post[3] = rs.getString("cmDate");
				cm_post[4] = rs.getString("cmContent");
				cm_post[5] = rs.getString("cmAvailable");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return cm_post;
	}
	
	public cmBean getcmBean(String cmRank) {
		connect();
		String sql = "select * from community where cmRank=?";
		cmBean cVO = new cmBean();
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cmRank);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				cVO.setCmRank(rs.getInt("cmRank"));
				cVO.setCmTitle(rs.getString("cmTitle"));
				cVO.setCmID(rs.getString("cmID"));
				cVO.setCmDate(rs.getString("cmDate"));
				cVO.setCmContent(rs.getString("cmContent"));
				cVO.setCmAvailable(rs.getInt("cmAvailable"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return cVO;
	}
	
			
	// 관리자 공지사항 글쓰기
	public int adminWrite(String adminTitle, String adminID, String adminContent) {
		connect();
		String SQL = "INSERT INTO AdminWrite VALUE(?, ?, ?, ?, ?, ?)"; 
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext2()); //인덱스
			pstmt.setString(2, adminTitle); //글 제목
			pstmt.setString(3, adminID); // 작성자 아이디
			pstmt.setString(4, getDate()); // 글 작성 시간
			pstmt.setString(5, adminContent); // 글 내용
			pstmt.setInt(6, 1); // 글 작성 가능 여부
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return -1; //데이터베이스 오류
	}
	
	// 관리자 공지사항 삭제
	public int adminDelete(int adminRank) {
		connect();
		int result = 1;
		String sql = "DELETE from AdminWrite where adminRank=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, adminRank);
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return result;
	}
	
	// 관리자 공지사항 수정
	public int adminUpdate(int adminRank, String adminTitle, String adminContent) {
		connect();
		int result = 0;
		String sql = "UPDATE adminwrite SET adminTitle=?, adminDate=?, adminContent=? WHERE adminRank=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, adminTitle);
			pstmt.setString(2, getDate());
			pstmt.setString(3, adminContent);
			pstmt.setInt(4, adminRank);
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return result;
	}
	
	// 글 목록 가져오기
		public ArrayList<cmAdBean> adminWriteList() {
			int num = 1;
			int rank;
			int count = 0;
			int[] reset_rank = new int[1000];
			// 위에 만들어놓은 connect()로 DB와 연결하기
			connect();
			// SQL 구문을 변수에 미리 집어 넣기 
			String dropSQL = "alter table `adminwrite` drop primary key";
			String alterSQL = "ALTER TABLE `AdminWrite` MODIFY COLUMN `adminRank` Int(20) PRIMARY KEY";
			String SQL = "SELECT * FROM adminwrite";
			String SQL_DESC = "SELECT * FROM adminwrite ORDER BY adminRank";
			// ArrayList<cmDAO>의 형태로 반환하기 위해서 list 객체 만들어주기
			ArrayList<cmAdBean> list = new ArrayList<cmAdBean>();
			try {
				// SQL 명령어를 준비시켜놓기
				PreparedStatement pstmt = conn.prepareStatement(SQL);
				// SQL 명령어 실행(SELECT * FROM adminwrite)
				ResultSet rs = pstmt.executeQuery();

				PreparedStatement dropPSTMT = conn.prepareStatement(dropSQL);
				try {
					dropPSTMT.executeUpdate();
				} catch(Exception e) {
					PreparedStatement alterPSTMT = conn.prepareStatement(alterSQL);
					alterPSTMT.executeUpdate();
					alterPSTMT.close();
					dropPSTMT.executeUpdate();
				} finally {
					dropPSTMT.close();
				}
				
				
				// 가져온 데이터를 하나씩 순차적으로 검색
				while(rs.next()) {
					// 사용자 객체를 만듦
					cmAdBean cAB = new cmAdBean();
					// 그 객체의 id를 rs(조회한 데이터)의 컬럼명 adminRank를 불러와서 설정 
					rank = rs.getInt("adminRank");
					while(num < rank) {
						reset_rank[num-1] = num;
						num = num + 1;
					}
					if(num == rank) {
						reset_rank[num-1] = rank; 
						num = num + 1;
					}
					updateAdminRank(reset_rank[count], rs.getInt("adminRank"));
					count = count + 1;
					// 멤버 리스트에 멤버 담기	
				}
				PreparedStatement alterPSTMT = conn.prepareStatement(alterSQL);
				try {
					alterPSTMT.executeUpdate();
				} catch(Exception e) {
					dropPSTMT.executeUpdate();
					dropPSTMT.close();
					alterPSTMT.executeUpdate();
				} finally {
					alterPSTMT.close();
				}
				rs.close();
				
				PreparedStatement pstmt2 = conn.prepareStatement(SQL_DESC);
				ResultSet rs2 = pstmt2.executeQuery();
				while(rs2.next()) {
					cmAdBean cAB = new cmAdBean();
					cAB.setAdminRank(rs2.getInt("adminRank"));
					cAB.setAdminTitle(rs2.getString("adminTitle"));
					cAB.setAdminID(rs2.getString("adminID"));
					cAB.setAdminDate(rs2.getString("adminDate"));
					cAB.setAdminContent(rs2.getString("adminContent"));
					cAB.setAdminAvailable(rs2.getInt("adminAvailable"));
					// 멤버 리스트에 멤버 담기
					list.add(cAB);
				}
				rs2.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			finally {
				disconnect();
			}
			return list; 
		}
		
		public void updateAdminRank(int updateRank, int originalRank) {
			String mainSQL = "UPDATE adminwrite SET adminRank=? WHERE adminRank=?";
			try {
				PreparedStatement mainPstmt = conn.prepareStatement(mainSQL);
				mainPstmt.setInt(1, updateRank);
				mainPstmt.setInt(2, originalRank);
				mainPstmt.executeUpdate();
				mainPstmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		//관리자 글 수정
		public static String[] adminWriteEdit(int adminRank) {
			connect();
			String sql = "select * from adminwrite where adminRank=?";
			String[] admin_post = new String[6];
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, adminRank);
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()) {
					admin_post[0] = rs.getString("adminRank");
					admin_post[1] = rs.getString("adminTitle");
					admin_post[2] = rs.getString("adminID");
					admin_post[3] = rs.getString("adminDate");
					admin_post[4] = rs.getString("adminContent");
					admin_post[5] = rs.getString("adminAvailable");
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				disconnect();
			}
			return admin_post;
		}
		
		public cmAdBean getAdBean(String adminRank) {
			connect();
			String sql = "select * from adminwrite where adminRank=?";
			cmAdBean cmVO = new cmAdBean();
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, adminRank);
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()) {
					cmVO.setAdminRank(rs.getInt("adminRank"));
					cmVO.setAdminTitle(rs.getString("adminTitle"));
					cmVO.setAdminID(rs.getString("adminID"));
					cmVO.setAdminDate(rs.getString("adminDate"));
					cmVO.setAdminContent(rs.getString("adminContent"));
					cmVO.setAdminAvailable(rs.getInt("adminAvailable"));
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				disconnect();
			}
			return cmVO;
		}
		
		public ArrayList<cmAdBean> getNotice() {
			connect();
			String sql = "SELECT * FROM adminwrite ORDER BY adminDate LIMIT 2";
			ArrayList<cmAdBean> list = new ArrayList<cmAdBean>();
			try {
				pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()) {
					cmAdBean cAB = new cmAdBean();
					cAB.setAdminRank(rs.getInt("adminRank"));
					cAB.setAdminTitle(rs.getString("adminTitle"));
					cAB.setAdminID(rs.getString("adminID"));
					cAB.setAdminDate(rs.getString("adminDate"));
					cAB.setAdminContent(rs.getString("adminContent"));
					cAB.setAdminAvailable(rs.getInt("adminAvailable"));
					list.add(cAB);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				disconnect();
			}
			return list; 
		}

}
