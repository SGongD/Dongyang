package memberRegister;

import java.sql.*;
import java.util.*;

public class RegisterMgr {
	private final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	private final String JDBC_URL = "jdbc:mysql://localhost:3306/moviesite?useUnicode=true&characterEncoding=utf-8";
	private final String USER = "root";
	private final String PASS = "root";
	
	public RegisterMgr() {
		try {
			Class.forName(JDBC_DRIVER);
		} catch(Exception e) {
			System.out.println("Error : JDBC 드라이버 로딩 실패");
		}
	}
	
	public int insertMember(RegisterBean mem) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		try {
			conn = DriverManager.getConnection(JDBC_URL, USER, PASS);
			
			pstmt = conn.prepareStatement("insert into memberMovie values (?, ?, ?, ?, ?, ?)");
			pstmt.setString(1, mem.getMemberid());
			pstmt.setString(2, mem.getPassword());
			pstmt.setString(3, mem.getName());
			pstmt.setString(4, mem.getEmail());
			pstmt.setString(5, mem.getTel());
			if(mem.getMemberid().equals("admin"))
				pstmt.setString(6, "관리자");
			else
				pstmt.setString(6, "GOLD");
			
			result = pstmt.executeUpdate();
		} catch (Exception ex) {
			System.out.println("Exception" + ex);
		} finally {
			if(rs!=null) try {rs.close();} catch(SQLException e) {}
			if(pstmt!=null) try {pstmt.close();} catch(SQLException e) {}
			if(conn!=null) try{conn.close();} catch(SQLException e) {}
		}
		return result;
	}
	
	public int login(String userid, String userpw) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DriverManager.getConnection(JDBC_URL, USER, PASS);
			String strQuery = "select password from membermovie where memberid = ?";
			pstmt = conn.prepareStatement(strQuery);
			pstmt.setString(1, userid);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getString(1).equals(userpw)) {
					return 1; // 로그인 성공
				}else
					return 0; // 비밀번호 불일치
			}
			return -1; // 아이디가 없음
		} catch (Exception ex) {
			System.out.println("Exception" + ex);
		}
		return -2; // DB 오류
	}
}

