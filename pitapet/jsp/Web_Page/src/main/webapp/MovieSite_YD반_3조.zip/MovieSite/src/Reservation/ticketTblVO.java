package Reservation;

public class ticketTblVO {
	private int ticketNum;
	private String ticketMovie;
	private String ticketCinema;
	private String ticketTimeline;
	private String ticketDate;
	private String ticketReservator;
	private int ticketPeople;
	
	public int getTicketNum() {
		return ticketNum;
	}
	public void setTicketNum(int ticketNum) {
		this.ticketNum = ticketNum;
	}
	public String getTicketMovie() {
		return ticketMovie;
	}
	public void setTicketMovie(String ticketMovie) {
		this.ticketMovie = ticketMovie;
	}
	public String getTicketCinema() {
		return ticketCinema;
	}
	public void setTicketCinema(String ticketCinema) {
		this.ticketCinema = ticketCinema;
	}
	public String getTicketTimeline() {
		return ticketTimeline;
	}
	public void setTicketTimeline(String ticketTimeline) {
		this.ticketTimeline = ticketTimeline;
	}
	public String getTicketDate() {
		return ticketDate;
	}
	public void setTicketDate(String ticketDate) {
		this.ticketDate = ticketDate;
	}
	public String getTicketReservator() {
		return ticketReservator;
	}
	public void setTicketReservator(String ticketReservator) {
		this.ticketReservator = ticketReservator;
	}
	public int getTicketPeoPle() {
		return ticketPeople;
	}
	public void setTicketPeoPle(int ticketPeople) {
		this.ticketPeople = ticketPeople;
	}
}
